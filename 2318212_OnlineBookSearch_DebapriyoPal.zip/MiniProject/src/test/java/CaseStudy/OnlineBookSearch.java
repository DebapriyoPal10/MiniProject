package CaseStudy;
import org.openqa.selenium.WebElement;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class OnlineBookSearch {

	public static void main(String[] args) throws InterruptedException {
		//Launching the browser.
		WebDriver driver = new ChromeDriver();
		
		
		//Going to http://www.bookswagon.com
		String baseUrl = "http://www.bookswagon.com/";
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get(baseUrl);
		driver.manage().window().maximize();
		
		
		//Finding Search textbox.
		driver.findElement(By.xpath("/html/body/form/header/div[1]/div/div[2]/div/input")).click();
		Thread.sleep(2000);
		
		
		//Entering "Selenium Webdriver" in the search textbox.
		driver.findElement(By.id("inputbar")).sendKeys("Selenium Webdriver");
		Thread.sleep(5000);
		
		
		//Clicking on Search button.
		driver.findElement(By.id("btnTopSearch")).click();
		Thread.sleep(2000);
		
		
		//Checking the number of search results displayed are greater than 10.
		String result = driver.findElement(By.xpath("//div[@class = 'preferences-show']/b")).getText();
		if(Integer.parseInt(result) > 10) {
			System.out.println("Number of search results: " + Integer.parseInt(result));
		}
		else {
			System.out.println("Number of search results is less than 10");
		}
		
		//Clicking on Sort by “Price Low to High”.
		Select select = new Select(driver.findElement(By.xpath("/html/body/form/div[10]/div[1]/div[2]/div[1]/div[2]/div/div[3]/select")));
		select.selectByVisibleText("Price - Low to High");
		Thread.sleep(2000);
		
		
		//Getting the name and price of first 5 displayed results and print.
		List<WebElement> productNames = driver.findElements(By.xpath("//div[@class = 'title']/a"));
		List<WebElement> productPrices = driver.findElements(By.xpath("//div[@class = 'sell']"));
		for (int i = 0; i< 5; i++) {
			
			System.out.println("Product Name : " + productNames.get(i).getText());
			System.out.println("Product Price : " + productPrices.get(i).getText());
		}
		
//		//Closing the browser.
		driver.quit();
	}

}
